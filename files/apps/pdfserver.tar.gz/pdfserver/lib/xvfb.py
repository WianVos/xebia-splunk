import os, tempfile, subprocess, threading, time
import logging
import fcntl

logger = logging.getLogger('splunk.pdfserver.lib.xvfb')


class XError(Exception):
    pass

class StartupError(XError):
    pass

class DisplayInUse(XError):
    pass

class XvfbManager(object):
    """
    Singleton that manages a pool of Xvfb servers
    """
    max_concurrent = 1
    op_lock = threading.RLock()

    def __init__(self, xvfb_path='Xvfb', xauth_path='xauth', mcookie_path='mcookie', max_concurrent=None):
        self.xvfb_path = xvfb_path
        self.xauth_path = xauth_path
        self.mcookie_path = mcookie_path
        if max_concurrent:
            self.max_concurrent = max_concurrent

        self.active_set = set()
        self.inactive_list = []

    def getServer(self):
        """
        Find a running instance of X from the pool or spin a new one up
        """
        self.op_lock.acquire()
        if self.inactive_list:
            s = self.inactive_list.pop(0)
            self.active_set.add(s)
        else:
            s = XvfbInstance(xvfb_path=self.xvfb_path, xauth_path=self.xauth_path, mcookie_path=self.mcookie_path)
            self.active_set.add(s)
            logger.info("Started new X server. Now %d active" % (len(self.active_set)))
        self.op_lock.release()
        return s

    def getActiveServer(self, display, clone=False):
        """
        Return an active server by its display number
        """
        for s in self.active_set:
            if s.display == int(display):
                return s
        if clone:
            # mock up an instance for use by screenshot grabber
            s = XvfbInstance(xvfb_path=self.xvfb_path, xauth_path=self.xauth_path, mcookie_path=self.mcookie_path)
            s.display = int(display)
            return s
        return None


    def releaseServer(self, s):
        """
        Release an X server to the pool for re-use
        """
        self.op_lock.acquire()
        self.active_set.remove(s)
        self.inactive_list.append(s)
        self.op_lock.release()

    def shutdown(self):
        """
        Kill all X instances
        """
        for x in list(self.active_set) + self.inactive_list:
            x.stop()
        self.active_list = set()
        self.inactive_list = []

class XvfbInstance(object):
    """
    Create and manage one instance of Xvfb
    """
    xauth_path = None
    auth_file = None
    auth_dir = None
    display = None
    display_lock_fh = None
    proc = None
    wait_for_x = 2

    def __init__(self, xvfb_path='Xvfb', xauth_path='xauth', mcookie_path='mcookie'):
        self.xvfb_path = xvfb_path
        self.xauth_path = xauth_path
        self.mcookie_path = mcookie_path

    def start(self):
        """
        Start the X server
        """
        self._prepare_display()
        args = [
            self.xvfb_path,
            ':%s' % (self.display),
            '-screen', '0', '3000x768x24',
            '-nolisten', 'tcp'
            ]
        env = {
            'XAUTHORITY': self.auth_file
        }

        try:
            logger.info('Starting X Server: %s' % args)
            logger.info('Starting X Server env: %s' % env)
            self.proc = subprocess.Popen(args, stdout=open('/dev/null', 'w'), stderr=subprocess.STDOUT, env=env)
            time.sleep(self.wait_for_x)
            if self.proc.returncode:
                self.proc.communicate()
                raise StartupError("X Failed to start")
            logger.info('X Started')
        except OSError:
            self._teardown_authority()
            raise StartupError('Failed to start Xvfb due to an invalid path anme')

    def stop(self):
        """
        Stop the X server
        """
        if self.proc:
            logger.warn('Stopping X Server %s' % self.display)
            self.proc.terminate()
            self.proc.communicate()
            self.proc = None
        self._teardown_authority()

    def restart(self):
        self.stop()
        self.start()

    def Popen(self, *a, **kw):
        """
        Run Popen and setup the environment variables required for the program
        to run as a client of the established X server
        """
        if not self.auth_file:
            self.start()
        if self.proc.returncode is not None: 
            logger.warn('X server appears to have crashed; restarting') 
            self.restart()

        if 'env' in kw:
            env = kw['env'].copy()
        else:
            env = {}

        env['DISPLAY'] = ':%s' % self.display
        env['XAUTHORITY'] = self.auth_file
        #logger.warn('env DISPLAY=:%s XAUTHORITY=%s' % (self.display, self.auth_file))
        kw['env'] = env

        return subprocess.Popen(*a, **kw)

    def screenshot(self):
        """
        Take a screenshot of the running X server and return the file handle of the data
        """
        auth_file = self.auth_file
        auth_dir = self._get_auth_dir(self.display, create=False)
        if not auth_dir:
            raise ValueError, "Server not running"
        auth_file = os.path.join(auth_dir, 'Xauthority')
        env = {
            'DISPLAY': ':%s' % self.display,
            'XAUTHORITY': auth_file
        }
        logger.debug("Exec DISPLAY=:%s XAUTHORITY=%s xwd -root -silent | convert - png:-", self.display, auth_file)
        proc = subprocess.Popen("/usr/bin/xwd -root -silent | /usr/bin/convert - png:-", stdout=subprocess.PIPE, shell=True, env=env)
        return proc.stdout

    def _prepare_display(self):
        """
        Find a free display number to use
        """
        for i in range(5,99):
            if not os.path.exists('/tmp/.X%s-lock' % i):
                try:
                    ourlock = None
                    ourlock = file('/tmp/.X%s-splunk-lock' % i, 'a+')
                    fcntl.flock(ourlock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    self.display_lock_fh = ourlock
                except Exception, e:
                    if ourlock:
                        ourlock.close()
                    logger.warn("Got lock exception while trying display %s: %s" % (i, e))
                    continue
                try:
                    self._setup_authority(i)
                except IOError, e:
                    logger.warn("Failed to create authority directory: %s" % (e,))
                    ourlock.close()
                    continue
                self.display = i
                logger.info("Assigned DISPLAY :%s" % i)
                return i
        raise StartupError("Failed to find a free DISPLAY number to use with Xvfb")

    def _get_auth_dir(self, display, create=True):
        base_dir = os.path.join(os.environ['SPLUNK_HOME'], 'var', 'run', 'splunk', 'xvfb')
        if not os.path.exists(base_dir):
            if not create:
                logger.error("base_dir does not exist: %s" % base_dir)
                return None
            os.mkdir(base_dir, 0700)
        auth_dir = os.path.join(base_dir, 'xauth-%s' % display)
        if not os.path.exists(auth_dir):
            if not create:
                logger.error("auth_dir no exist: %s" % auth_dir)
                return None
            os.mkdir(auth_dir, 0700)
        return auth_dir

    def _setup_authority(self, display):
        """
        Create an Xauthority file
        """
        self.auth_dir = self._get_auth_dir(display)
        self.auth_file = os.path.join(self.auth_dir, 'Xauthority')
        open(self.auth_file, 'a+').close()

        try:
            mc = subprocess.Popen(self.mcookie_path, stdout=subprocess.PIPE, bufsize=1)
            cookie = mc.communicate()[0].strip()
        except OSError:
            self._teardown_authority()
            raise StartupError('Failed to generate X cookie')

        try:
            args = [
                self.xauth_path,
                '-f', self.auth_file,
                'add',
                ':%s' % display,
                '.',
                cookie
            ]
            xa = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            err = xa.communicate()[0].strip()
            if err:
                logger.warn('Got response from xauth: %s' % err)
        except OSError:
            self._teardown_authority()
            raise StartupError('Failed to run xauth')

    def _teardown_authority(self):
        if self.display_lock_fh:
            os.unlink(self.display_lock_fh.name)
            fcntl.flock(self.display_lock_fh.fileno(), fcntl.LOCK_UN)
            self.display_lock_fh.close() # will unlock the file
        if self.auth_file:
            os.unlink(self.auth_file)
            os.rmdir(self.auth_dir)
        self.display_lock_fh = self.auth_file = self.auth_dir = None


