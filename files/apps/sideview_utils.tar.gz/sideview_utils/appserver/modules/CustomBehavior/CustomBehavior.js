// Copyright (C) 2010-2013 Sideview LLC.  All Rights Reserved.


Splunk.Module.CustomBehavior = $.klass(Splunk.Module.DispatchingModule, {
    initialize: function($super, container) {
        $super(container);
        Sideview.utils.applyCustomProperties(this);
    },

    requiresDispatch: function($super, search) {
        return (this.getParam("requiresDispatch") == "True" && $super(search));
    },

    /** 
     * see comment on DispatchingModule.requiresTransformedResults
     */
    requiresTransformedResults: function() {
        return true;
    }

});