/* Copyright (C) 2010-2013 Sideview LLC.  All Rights Reserved. */

/*
if ($.browser.safari && /chrome/.test(navigator.userAgent.toLowerCase())) {
    alert("Warning: Google Chrome is currently not supported for use with the Sideview Editor.  Specifically there is a bug in Chrome that we're still trying to work around.  Please use the Sideview Editor in Mozilla Firefox,  Safari or Internet Explorer instead");
}
*/
    
function getViewWindow() {
    return window.frames["view"];
}
function getEditWindow() {
    return window.frames["editWindow"];
}
function getSchematicWindow() {
    return window.frames["schematic"];
}
function getControlWindow() {
    return window.frames["controls"];
}

Sideview = {}
Sideview.Editor = {
    primarySelectedNode: false,
    activeModuleSelector: false,
    mode:"Edit",
    currentApp: initialApp,
    currentView: initialView,
    instrumentedModule: false,

    setAppViewAndMode: function(app,view,mode) {

        Sideview.Editor.mode = mode;

        if (app!=Sideview.Editor.currentApp || view!=Sideview.Editor.currentView) {
            var viewWindow = getViewWindow();
            viewWindow.document.location = Splunk.util.make_url("/app/" + app + "/" + view)

            var schematicWindow = getSchematicWindow();
            sURL = "/custom/sideview_utils/view/spacetree?app=" + app + "&view=" + view;
            schematicWindow.document.location = Splunk.util.make_url(sURL);
            
            Sideview.Editor.currentApp  = app;
            Sideview.Editor.currentView = view;
            
            viewWindow = null;
            schematicWindow = null;
        }
        switch(mode) {
            case "Edit":
                Sideview.Editor.displayModuleSelectionForm(app,view,"edit");
                break;
            case "Add" :
                Sideview.Editor.displayModuleClassForm(app,view);
                break;
            case "Delete" :
                Sideview.Editor.displayModuleSelectionForm(app,view,"delete");
                break;
            case "Reattach" :
                Sideview.Editor.displayModuleReattachForm(app,view);
                break;
            case "Debug" :
                Sideview.Editor.displayModuleSelectionForm(app,view,"debug");
                break;
        }
        
    },

    displayViewEditForm: function() {
        var url = ["/custom/sideview_utils/view/edit?app="  + Sideview.Editor.currentApp];
        url.push("view=" + Sideview.Editor.currentView);
        window.parent.frames["editWindow"].document.location = Splunk.util.make_url(url.join("&"))
    },

    displayNewViewForm: function(app) {
        var url = ["/custom/sideview_utils/view/edit?app=" + app];
        url.push("view=_new");
        window.parent.frames["editWindow"].document.location = Splunk.util.make_url(url.join("&"))
    },

    displayModuleSelectionForm: function(app,view,action,message) {
        var url = ["/custom/sideview_utils/module/choose_existing?app=" + app];
        url.push("view=" + view);
        url.push("action=" + action);
        if (message) {
            url.push("successMessage=" + message);
        }
        window.parent.frames["editWindow"].document.location = Splunk.util.make_url(url.join("&"));
    },

    displayModuleReattachForm: function(app,view,message) {
        var url = ["/custom/sideview_utils/module/reattach_existing?app=" + app];
        url.push("view=" + view);
        if (message) {
            url.push("successMessage=" + message);
        }
        window.parent.frames["editWindow"].document.location = Splunk.util.make_url(url.join("&"));
    },

    displayModuleClassForm: function(app,view,message) {
        var url = ["/custom/sideview_utils/module/add_new?app=" + app];
        url.push("view=" + view);
        if (message) {
            url.push("successMessage=" + message);
        }
        window.parent.frames["editWindow"].document.location = Splunk.util.make_url(url.join("&"));
    },

    selectView: function() {
        if (Sideview.Editor.activeModuleSelector 
                && Sideview.Editor.activeModuleSelector[0]) {

            Sideview.Editor.activeModuleSelector[0].val("(the view itself)");
            Sideview.Editor.activeModuleSelector[1].val("view");
            switch (Sideview.Editor.mode) {
                case "Edit" :
                    parent.Sideview.Editor.displayViewEditForm();
                    //Sideview.Editor.enableSubmitButton()
                    break;
            }
        }
        else if (Sideview.Editor.mode=="Edit") {
            Sideview.Editor.displayViewEditForm();
        }
    },

    enableSubmitButton: function() {
        var editWindow = getEditWindow();
        editWindow.$("input[type='submit']").removeAttr("disabled");
        editWindow = null;
    },

    selectModule: function(moduleId) {
        var viewWindow = getViewWindow();
        if (viewWindow.Splunk) {

            var module = viewWindow.Splunk.Globals.ModuleLoader.getModuleInstanceById(moduleId);
            var container = module.container;
            if (container) {
                viewWindow.$(".selectedModuleForEditing").removeClass("selectedModuleForEditing");
                container.addClass("selectedModuleForEditing");
            }
        }
        var moduleClass=moduleId.split("_")[0];
        

        //window.parent.frames["schematic"].passiveSelectModule(moduleId);
        
        // direct edit mode, where the click goes immediately to the edit form....
        if (Sideview.Editor.mode=="Edit") {
            url = ["/custom/sideview_utils/module/edit?app="  + Sideview.Editor.currentApp];
            url.push("view=" + Sideview.Editor.currentView);
            url.push("moduleId=" + moduleId);
            url.push("moduleClass=Splunk.Module." + moduleClass);
            var editWindow = getEditWindow();
            editWindow.document.location = Splunk.util.make_url(url.join("&"));
        }
        else if (Sideview.Editor.mode == "Debug") {
            var module = viewWindow.Splunk.Globals.ModuleLoader.getModuleInstanceById(moduleId);
        
            Sideview.Editor.debugAtModule(module);
            

        }
        if (Sideview.Editor.activeModuleSelector 
            && Sideview.Editor.activeModuleSelector[0] 
            && Sideview.Editor.activeModuleSelector[0].is(":visible")) {
            Sideview.Editor.activeModuleSelector[0].val(moduleId);
            Sideview.Editor.activeModuleSelector[1].val("Splunk.Module." + moduleClass);
        }
            
        var title, text;
        switch (Sideview.Editor.mode) {
            case "Edit" :
                title = "You've now selected a module to edit";
                text = "If it's the module you wanted to edit, great. If not, keep navigating around in the schematic window by dragging and clicking. More modules may become visible up as you interact with the schematic.";
                break;

            case "Delete":
                title = "You've now selected a module to potentially delete";
                text = "If it's the module you wanted, great. If not, keep navigating around in the schematic window by dragging and clicking. More modules may become visible up as you interact with the schematic. Nothing will be deleted until you click the green button.  <br><br>BE CAREFUL DELETING MODULES AND REMEMBER THAT IF THERE ARE OTHER MODULES DOWNSTREAM THOSE WILL BE OBLITERATED AS WELL. ";
                Sideview.Editor.enableSubmitButton()
                break;

            case "Add":
                title = "You've now selected a module to be the parent of your new module";
                text = "If it's the module you wanted to choose, great. If not, keep navigating around in the schematic window by dragging and clicking. More modules may become visible up as you interact with the schematic.";
                break;
            
            case "Reattach":
                title = "You've now selected a module to remove and reattach elsewhere";
                text = "When you remove and reattach modules, any other modules that exist downstream will be carried along in the process.  Most commonly you'll use this mode to 'stitch in' a new module into the hierarchy.  In other words you'll use the 'Add' mode to add a new module somewhere, and then you'll 'reattach' one of that new module's siblings to be the new module's child.";
                break;

            case "Debug":
                title = "You've now selected a module to debug";
                text = "In Runtime Debug mode, you'll see a breakdown of any searches, timeranges and other data (if any) that this module provides for downstream modules.  You'll also see a breakdown of all the searches, timeranges and other data that this module <b>inherits</b> from other modules upstream.   <br><br>This mode is extremely useful for debugging complex form searches and inline drilldown views.<br><br>Note that you can interact with the view panel and you will see the debug panel update in real time.";
                break;
            }
        Sideview.Editor.displayHelp(title, text);
        viewWindow = null;
        container = null;
        module = null;
        
    },

    reloadSchematic: function(appAndViewUrl,selectedNode) {
        if (selectedNode && selectedNode!="_top") {
            appAndViewUrl += "&selectedNode=" + selectedNode;
        }
        window.parent.frames["schematic"].document.location = appAndViewUrl;
    },

    displayHelp: function(title, text) {
        if (frames["description"].document 
          && frames["description"].document.location 
          && frames["description"].document.location.href.indexOf("description")!=-1) {
            frames["description"].$(".title").text(title);
            frames["description"].$(".text").html(text);
        } else {
            descUrl = "/app/sideview_utils/description?title=" + title + "&text=" + text;
            frames["description"].document.location = Splunk.util.make_url(descUrl);
        }

    },

    setInstrumentedModule: function(module) {
        var previousModule = Sideview.Editor.instrumentedModule;

        if (previousModule) {
            previousModule.pushContextToChildren = previousModule._pushContextToChildren;
            previousModule.onContextChange = previousModule._onContextChange;
            previousModule._pushContextToChildren = null;
            previousModule._onContextChange = null;
        }

        module._pushContextToChildren = module.pushContextToChildren;
        module._onContextChange = module.onContextChange;

        module.pushContextToChildren = function(explicitContext) {
            Sideview.Editor.debugAtModule(this);
            this._pushContextToChildren(explicitContext);
        }.bind(module);

        module.onContextChange = function() {
            Sideview.Editor.debugAtModule(this);
            this._onContextChange();
        }.bind(module);


        Sideview.Editor.instrumentedModule = module;

    },

    getSearchKeysAsContext: function(context) {
        var viewWindow = getViewWindow();
        var cleanContext = new viewWindow.Splunk.Context();
        viewWindow = null;
        
        var search = context.get("search");
        if (search) {
            cleanContext.set("search", search.toString());
        }
        
        var range = search.getTimeRange();
        var earliest = range.getEarliestTimeTerms();
        var latest = range.getLatestTimeTerms();
        if (!earliest) earliest = " ";
        if (!latest)  latest = " ";
        var timeRangeStr = [];
        if ((earliest && earliest!=0) && latest) {
            timeRangeStr.push("(" + earliest + ","+ latest + ") ");
        }
        timeRangeStr.push(range.toConciseString());

        cleanContext.set("timerange", timeRangeStr.join(" "));

        var postProcess = search.getPostProcess();
        if (postProcess) {
            cleanContext.set("postprocess", postProcess);
        }
        if (search.job && search.job.getSearchId()) {
            cleanContext.set("search id", search.job.getSearchId());
        }
        if (search.hasIntentions) {
            cleanContext.set("number of intentions", search._intentions.length);
        }
        return cleanContext;
    },

    clobberSearchKeys: function(context) {
        var unwantedKeys = ["search", "timerange", "search.timeRange.earliest","search.timeRange.latest","search.timeRange.label"];
        var key;
        // it'd be nice to rely on the Context.remove() method that SideviewUtils adds
        // however then we'd only be able to edit Sideview view.
        for (var i=0;i<unwantedKeys.length;i++) {
            key = unwantedKeys[i];
            if (context.has(key)) {
                context.set(key,null);
                // nothing to see here...  move along. 
                context._root[key];
            }
        }
    },

    
    getContextKeys: function(context) {
        var keys = [];
        for (key in context._root) {
            if (context.has(key)) {
                keys.push(key);
            }
        }
        return keys;
    },
    contextValuesAreEqual: function(val1, val2) {
        if (!val1 && !val2) return true;
        else if (!val1 || !val2) return false;

        if (val1 == val2) return true;
        if (val1.toString && val2.toString && val1.toString()==val2.toString())  return true;
        //could in theory use Splunk.util.objectSimilarity() ....
        return false;

    },


    diffContext: function(context, modifiedContext) {
        var keys = Sideview.Editor.getContextKeys(context);
        var modifiedKeys = Sideview.Editor.getContextKeys(modifiedContext);
        
        for (var i=modifiedKeys.length-1;i>=0;i--) {
            var key = modifiedKeys[i];
            if (keys.indexOf(key)!=-1 
                && (Sideview.Editor.contextValuesAreEqual(context.get(key), modifiedContext.get(key)))) {
                modifiedKeys.splice(i,1);
            }
        }
        keys = keys.sort();
        modifiedKeys = modifiedKeys.sort();

        return modifiedKeys;
    },

    renderContextKeys: function(editorTable, context, renderOnlyTheseKeys) {
        var keys = renderOnlyTheseKeys || Sideview.Editor.getContextKeys(context);

        for (var i=keys.length-1;i>=0;i--) {
            var isFunction = (typeof context.get(keys[i]) === "function");
            var nullValued = !context.get(keys[i]);
            
            if (isFunction || nullValued) {
                keys.splice(i,1);
            }
        }
        for (var i=0,len=keys.length;i<len;i++) {
            var value = context.get(keys[i]);
            
            var tr = $("<tr>");
            tr.append($("<td>").text(keys[i]));
            tr.append($("<td>").text(value.toString()));
            editorTable.append(tr);
        }
        if (keys.length==0) {
            var tr = $("<tr>");
            tr.append($('<td colspan="3">').text("(none)"));
            editorTable.append(tr);
        }
    },

    addNewHeaderRow: function(editorTable, headerStr) {
        editorTable.append($('<tr class="spacer">').append($('<td colspan="3">').append(" ")));

        var header = $("<h4>").text(headerStr);
        editorTable.append(
            $('<tr class="header">').append(
                $('<td colspan="3">').append(header)));
    },

    debugAtModule: function(module) {
        var editWindow = getEditWindow();
        var outerWrapper = editWindow.$("div.outerWrapper");
        outerWrapper.html('');

        Sideview.Editor.setInstrumentedModule(module);

        var context = module.getContext();
        var modifiedContext = module.getModifiedContext();
        outerWrapper.append(
            $("<h2>").text("Debug Module : " + module.moduleId)
        );

        var editorTable = $('<table cellspacing="0">').addClass("viewerTable");
        
        var searchKeysAsContext = Sideview.Editor.getSearchKeysAsContext(context);
        
        // 1 ---------------------------------
        Sideview.Editor.addNewHeaderRow(editorTable, "Search values added/modified for downstream modules");
        
        var modifiedSearchKeysAsContext = Sideview.Editor.getSearchKeysAsContext(modifiedContext);
        var modifiedSearchKeysList = Sideview.Editor.diffContext(searchKeysAsContext, modifiedSearchKeysAsContext);
        Sideview.Editor.renderContextKeys(editorTable, modifiedSearchKeysAsContext, modifiedSearchKeysList);
        

        // 2 ---------------------------------

        Sideview.Editor.addNewHeaderRow(editorTable, "Normal keys added/modified for downstream modules")
        

        var clobberedNormal = context.clone();
        var clobberedModified = modifiedContext.clone();
        Sideview.Editor.clobberSearchKeys(clobberedNormal);
        Sideview.Editor.clobberSearchKeys(clobberedModified);
        var modifiedKeys = Sideview.Editor.diffContext(clobberedNormal, clobberedModified);
        Sideview.Editor.renderContextKeys(editorTable, clobberedModified, modifiedKeys);
        

        editorTable.append($('<tr class="spacer">').append($('<td colspan="3">').append(" ")));
        editorTable.append($('<tr class="spacer">').append($('<td colspan="3">').append(" ")));
         // 3 ---------------------------------
        Sideview.Editor.addNewHeaderRow(editorTable, "Search values inherited from upstream");
        
        
        Sideview.Editor.renderContextKeys(editorTable, searchKeysAsContext);

        // 4 ---------------------------------
        Sideview.Editor.addNewHeaderRow(editorTable, "Normal keys inherited from upstream")
        
        Sideview.Editor.renderContextKeys(editorTable, clobberedNormal);

        outerWrapper.append(editorTable);
    },

    updateControlWindow: function(app, view) {
        var controlWindow = getControlWindow();
        baseHref = controlWindow.location.href;
        if (baseHref.indexOf("?")!=-1) {
            baseHref = baseHref.substring(0,baseHref.indexOf("?"))
        }
        controlWindow.location.href = baseHref + "?app=" + app + "&view=" + view;
        controlWindow = null;
    },

    
    activateEditingInterface: function() {
        var viewWindow = getViewWindow();
        viewWindow.$("body").addClass("editMode");
        
        viewWindow.$("div.SplunkModule").click(function() {
            if (Sideview.Editor.mode != "Debug") {
                var module = window.top.frames["view"].Sideview.utils.getModuleFromDOMElement($(this));
                window.top.Sideview.Editor.selectModule(module.moduleId);
            }
        });
        viewWindow = null;
    },
    

    setActiveModuleSelector: function(idInput, classInput) {
        Sideview.Editor.activeModuleSelector = [idInput, classInput];
    },

    success: function(app,view) {
        switch (Sideview.Editor.mode) {
        case "Edit" :
            Sideview.Editor.displayModuleSelectionForm(app,view,"edit", "modified settings submitted successfully");
            break;
        case "Add":
            Sideview.Editor.displayModuleClassForm(app,view,"new module added successfully");
            break;
        }
    },
    fail: function(message) {
        var editWindow = getEditWindow();
        editWindow.$("div.fail").remove();
        editWindow.$("<div>")
            .addClass("fail")
            .text(message)
            .prependTo(editWindow.document.body)
        $(editWindow).scrollTop(0)
        
    }

};

// bizarre, but no combination of normal load/ready events seemed to work 
// on the frame objects.  This is called from an olschool onload attribute.
function attachEditorEventHandler() {
    Sideview.Editor.activateEditingInterface();
}
