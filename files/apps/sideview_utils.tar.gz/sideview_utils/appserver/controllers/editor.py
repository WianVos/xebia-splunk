#Copyright (C) 2010-2013 Sideview LLC.  All Rights Reserved. 

import logging, cherrypy
import splunk.appserver.mrsparkle.controllers as controllers
from splunk.appserver.mrsparkle.lib.decorators import expose_page

logger = logging.getLogger('splunk.appserver.controllers.editor')


# URL: /custom/sideview_utils/editor/top
class editor(controllers.BaseController):

    @expose_page(must_login=True, methods=['GET']) 
    def top(self, app, view, **kwargs):
        return self.render_template('/sideview_utils:/templates/editor.html', {
            "view": view, 
            "app" : app, 
            "base_view_url" : "/app/"+ app, 
            "base_editor_view_url" : "/app/sideview_utils", 
            "base_controller_url" : "/custom/sideview_utils/",
            "base_url": "/static/app/sideview_utils"
        })
    
    @expose_page(must_login=True, methods=['GET']) 
    def controls(self,**kwargs) :
        return self.render_template('/sideview_utils:/templates/controls.html', {
            "base_url" : "/static/app/sideview_utils"
        })
    