#Copyright (C) 2010-2013 Sideview LLC.  All Rights Reserved. 

import logging, json, re, cherrypy
import lxml.etree as et
import splunk.appserver.mrsparkle.controllers as controllers
from splunk.appserver.mrsparkle.lib.decorators import expose_page


import sideview as sv

logger = logging.getLogger('splunk.appserver.controllers.view')


class view(controllers.BaseController):

    @expose_page(must_login=True, methods=['GET']) 
    def show(self, app, view, **kwargs):
        cherrypy.response.headers['Content-Type'] = "text/xml"

        uglyXML = sv.getViewXML(app,view)
        uglyXML = uglyXML.toxml()
        parser = et.XMLParser(remove_blank_text=True,strip_cdata=False)
        etXML = et.XML(uglyXML,parser)
        prettyXML = et.tostring(etXML,pretty_print=True)

        viewXML = sv.patchXMLForReadability(prettyXML)
        return viewXML

    # returns a simplified version of the module tree in JSON.
    @expose_page(must_login=True, methods=['GET']) 
    def spacetree(self,app,view,**kwargs) :
        viewXML = sv.getViewXML(app,view)
        selectedNode = kwargs.get("selectedNode",None)
            
        if (len(viewXML.getElementsByTagName("view"))>0) :
            sv.addIdsToAllModules(viewXML)
            viewJSON = {}
            viewJSON["id"] = view
            viewJSON["name"] = view
            viewJSON["data"] = {"isView": True}
            
            if (viewXML.childNodes.length>0) : 
                viewTag = viewXML.getElementsByTagName("view")[0]
                sv.buildModulesAsJSON(viewJSON, viewTag)

            return self.render_template("/sideview_utils:/templates/spacetree.html", {
                "app" : app, 
                "view": view, 
                "selectedNode" : selectedNode,
                "base_url" : self.make_url("/static/app/sideview_utils/"), 
                "viewJSON" : json.dumps(viewJSON)
            })

        else :
            if (len(viewXML.getElementsByTagName("form"))>0):
                simplifiedXMLType="form"
            elif (len(viewXML.getElementsByTagName("dashboard"))>0):
                simplifiedXMLType="dashboard"
            else :
                simplifiedXMLType=None
            
            message = []
            if (simplifiedXMLType):
                message.append("it looks like this is a <b>&lt;")
                message.append(simplifiedXMLType)
                message.append('&gt;</b> view.  You can try converting this view to the advanced XML using the process described <a target="_blank" href="http://splunk-base.splunk.com/answers/1/how-can-i-convert-simple-view-xml-to-advanced-xml">here.</a> ');
            else :
                message.append("We're not sure what happened here,but the Sideview Editor was unable to read the XML for this view.")

            return self.render_template("/sideview_utils:/templates/general_description.html", {
                "title":  "Sorry the Sideview Editor does not support editing views written using Splunk's Simplified XML.",
                "text":"",
                "escapedText": "".join(message),
                "base_url" : self.make_url("/static/app/sideview_utils/")
            })



    @expose_page(must_login=True, methods=['GET']) 
    def edit(self,view,app) :
        
        if (view=="_new") :
            viewXML = sv.getBlankViewXML()
        else :
            viewXML = sv.getViewXML(app,view)
        
        viewAttributes = sv.getViewAttributeMap()
        
        # weird looking, but we just want the keys so we wipe the values.
        for name,val in viewAttributes.items() :
            viewAttributes[name] = ""

        viewNode = viewXML.getElementsByTagName("view")[0]

        for name,value in viewNode.attributes.items():
            viewAttributes[name] = viewNode.getAttribute(name)
            
        label = sv.getText(viewXML.getElementsByTagName("label")[0])

        return self.render_template("/sideview_utils:/templates/edit_view_params.html", {
            "viewAttributes":viewAttributes, 
            "label" : label, 
            "app":app,
            "view":view, 
            "base_url" : self.make_url("/static/app/sideview_utils/", translate=False)
        })

    @expose_page(must_login=True, methods=['GET']) 
    def describe(self,param=None,**kwargs) :

        m = sv.getViewAttributeMap()
        if (param == "label") :
            text = """(required) When set, this value will represent the view in navigation menus"""
        elif (param=="name") :
            text = """(required) This determines the name of the view in URL's 
            and determines the name of the XML file(s) on disk.  You can only set 
            this value when the view is first created."""
        else :
            text = m.get(param,False)

        return self.render_template("/sideview_utils:/templates/general_description.html", {
            "title":  'view param "' + param  + '"',
            "text": text,
            "escapedText": "",
            "base_url" : self.make_url("/static/app/sideview_utils/", translate=False)
        })

    @expose_page(must_login=True, methods=["POST"]) 
    def update_view_props(self,app,view,label, **kwargs):
        
        if (not self.viewIsEditable(app,view)) :
            return self.getUneditableAppResponse(app,view)

        if (view=="_new") :
            viewNameIfNew = kwargs.get("name")
            viewXML = sv.getBlankViewXML()
        else :
            viewNameIfNew = None
            viewXML = sv.getViewXML(app,view)

        viewAttributes = sv.getViewAttributeMap()

        viewNode = viewXML.getElementsByTagName("view")[0]
        
        existingAttributeMap = {}
        for name,value in viewNode.attributes.items():
            existingAttributeMap[name] = value
        for name in viewAttributes:
            if (kwargs.get(name,None)) :
                viewNode.setAttribute(name,kwargs[name])
            elif (name in existingAttributeMap):
                viewNode.removeAttribute(name)
        
        labelNode = viewXML.getElementsByTagName("label")[0]
        sv.clearContents(labelNode)
        sv.setText(viewXML, labelNode, label)
        updateMetaData = "action=viewPropertyEdit"

        errorMessage = sv.commitChanges(app,view,viewXML,updateMetaData,viewNameIfNew)
        if (errorMessage) :
            return self.getErrorResponse(errorMessage)
        return '{"success":true}'


    
    @expose_page(must_login=True, methods=["POST"]) 
    def delete_module(self, app, view, moduleId, **kwargs) :
        
        if (not self.viewIsEditable(app,view)) :
            return self.getUneditableAppResponse(app,view)
        
        viewXML = sv.getViewXML(app,view)

        sv.addIdsToAllModules(viewXML)
        moduleToDelete = viewXML.getElementById(moduleId)
        parentNode = moduleToDelete.parentNode
        parentNode.removeChild(moduleToDelete)

        updateMetaData = "action=deleteModule moduleId=" + str(moduleId)
        errorMessage = sv.commitChanges(app,view,viewXML,updateMetaData)
        if (errorMessage) :
            return self.getErrorResponse(errorMessage)
        return '{"success":true}'
    
    @expose_page(must_login=True, methods=['POST']) 
    def reattach_module(self, view, app, moduleId, parentModuleId, **kwargs) : 
        # weirdness in exception handling, where an exception deeper in, 
        # triggers a useless error message and a 404 response, where the 
        # response complains about optional args not being passed.
        # I'm writing it this way, just so that problem doesn't slow us down 
        # when we hit inevitable exceptions during development.
        insertBeforeModuleId=kwargs.get("insertBeforeModuleId",None) 
        successMessage=kwargs.get("successMessage",None) 

        if (not self.viewIsEditable(app,view)) :
            return self.getUneditableAppResponse(app,view)

        if (moduleId == parentModuleId) :
            return '{"success":false,"message": "Sorry but you just tried to make ' + moduleId + ' a parent of itself.  Check your field values and try again."}'

        viewXML = sv.getViewXML(app,view)

        sv.addIdsToAllModules(viewXML)
        ourModule = viewXML.getElementById(moduleId)
        newParent = viewXML.getElementById(parentModuleId)
        

        # drum roll please
        oldParent = ourModule.parentNode
        oldParent.removeChild(ourModule)

        # if the module will become a top-level module AND it doesn't have layoutPanel set,  
        # then explicitly give it the layoutPanel that it's old parent had.
        if (parentModuleId=="(the view itself)") :
            newParent=viewXML.getElementsByTagName("view")[0]
            if (not ourModule.hasAttribute("layoutPanel")) :
                value, inheritedValue = sv.getAttributeValueForModule(app,view,oldParent.getAttribute("id"), "layoutPanel")
                explicitLayoutPanel = value
                if (not explicitLayoutPanel) :
                    explicitLayoutPanel = inheritedValue 
                ourModule.setAttribute("layoutPanel", explicitLayoutPanel)

        if (insertBeforeModuleId) :
            if (insertBeforeModuleId == moduleId) :
                return '{"success":false,"message": "Sorry but you tried to insert ' + moduleId + ' just before itself and that\'s not possible.  Check your field values and try again."}'

            insertBeforeModule = viewXML.getElementById(insertBeforeModuleId)
            if (insertBeforeModule and insertBeforeModule.parentNode != newParent) :
                return '{"success":false,"message": "Sorry but ' + insertBeforeModuleId + ' is not itself a child of ' + parentModuleId+ ' so this is impossible. Please check your field values and try again."}'

            newParent.insertBefore(ourModule,insertBeforeModule)
        else : 
            newParent.appendChild(ourModule)
        
        updateMetaData = "action=moduleReattached moduleId=%s parentModuleId=%s insertBeforeModuleId=%s" % (moduleId, parentModuleId, insertBeforeModuleId)
        errorMessage = sv.commitChanges(app,view,viewXML, updateMetaData)
        if (errorMessage) :
            return self.getErrorResponse(errorMessage)
        return '{"success":true}'
        
    
    
    @expose_page(must_login=True, methods=["POST"]) 
    def update(self, app, view, moduleId, **kwargs) :

        if (not self.viewIsEditable(app,view)) :
            return self.getUneditableAppResponse(app,view)
            
        viewXML = sv.getViewXML(app,view)
        sv.addIdsToAllModules(viewXML)
        
        moduleParams = {}
        
        # we avoid using optional args in the controller to avoid the buggy exception handling in Splunk's python code for controllers.
        parentModuleId=kwargs.get("parentModuleId",None) 
        insertBeforeModuleId=kwargs.get("insertBeforeModuleId",None) 
        moduleClass=kwargs.get("moduleClass",None) 

        legalAttributeValues = sv.getLegalValuesForModule(viewXML,moduleClass)
        
        moduleAttributeMap = {
            "layoutPanel" : kwargs.get("layoutPanel",None),
            "autoRun": kwargs.get("autoRun",None),
            "group": kwargs.get("group",None)
        }
        
        
        for attName in legalAttributeValues :
            submittedValue = kwargs.get(attName,None)
            attDict = legalAttributeValues[attName]
            if (submittedValue):
                if ("values" in attDict and attDict["values"] and submittedValue not in attDict["values"]) :
                    return self.getAttributeErrorResponse(attName,attDict["values"],submittedValue,attDict["required"])
            elif ("required" in attDict and attDict["required"]) :
                return '{"success":false,"message": "' + attName + ' is a required field."}'


        for arg in kwargs: 
            if (arg not in {"view","app","moduleID","parentModuleId","insertBeforeModuleId","layoutPanel","autoRun","moduleClass","splunk_form_key"}) :
                value = kwargs[arg]
                try : 
                    # json.loads will turn false to False and true to True so 
                    # we guard against that here.
                    if (value!="false" and value!="true") :
                        value = json.loads(value)
                except Exception,e:
                    m = "exception trying convert following string to json - " + str(value)
                    logger.error(m)
                    
                moduleParams[arg] = value
                
        if (moduleId=="_new" and moduleClass) :
            if (parentModuleId!="_top") : 
                parentModule = viewXML.getElementById(parentModuleId)
                ourModule = viewXML.createElement("module")
                ourModule.setAttribute("name",moduleClass)
                if (insertBeforeModuleId and insertBeforeModuleId != parentModuleId) :
                    insertBeforeModule = viewXML.getElementById(insertBeforeModuleId)
                    parentModule.insertBefore(ourModule,insertBeforeModule)
                else :
                    parentModule.appendChild(ourModule)
                
            else : 
                
                viewNode = viewXML.getElementsByTagName("view")[0]
                ourModule = viewXML.createElement("module")
                ourModule.setAttribute("name",moduleClass)
                ourModule.setAttribute("layoutPanel","appHeader")
                viewNode.appendChild(ourModule)

        else :
            ourModule = viewXML.getElementById(moduleId)
            #logger.error("we are editing this module: " + moduleId)
        
        if (ourModule.parentNode.tagName=="view") :
            layoutPanel = kwargs.get("layoutPanel",None) 
            if (not layoutPanel) :
                return self.getErrorResponse("all top level modules must have a value set for 'layoutPanel'.")

        for attName,attValue in moduleAttributeMap.items() :
            if (attValue) :
                ourModule.setAttribute(attName,attValue)
            elif (ourModule.hasAttribute(attName)) :
                ourModule.removeAttribute(attName)
            
        for param in ourModule.childNodes :
            if (param.nodeType == param.TEXT_NODE) :
                ourModule.removeChild(param)
        for param in ourModule.childNodes :
            if (param.nodeType != 1 or param.tagName!="param") :
                continue;
            paramName = param.getAttribute("name")
            sv.clearContents(param)

            if paramName in moduleParams :
                value = moduleParams[paramName]
                if (isinstance(value,list)) :
                    sv.setListParam(viewXML, param, value)
                elif (sv.isBigParam(moduleClass,paramName)) :
                    sv.setCDATA(viewXML, param, value)
                else :
                    sv.setText(viewXML, param, value)
                del moduleParams[paramName]
            else :
                ourModule.removeChild(param)
                
        
        for remainingParamName in moduleParams : 
            newParam = viewXML.createElement("param")
            
            newParam.setAttribute("name", remainingParamName)
            
            value = moduleParams[remainingParamName]
            if (isinstance(value,list)) :
                sv.setListParam(viewXML, newParam, value)
            else :
                sv.setText(viewXML, newParam, str(value))

            
            if (ourModule.childNodes.length>0) :
                ourModule.insertBefore(newParam, ourModule.childNodes[0])
            else : 
                ourModule.appendChild(newParam)

        if (moduleId=="_new") :
            updateMetaData = "action=moduleAdded moduleClass=%s parentModuleId=%s insertBeforeModuleId=%s" % (moduleClass, parentModuleId, insertBeforeModuleId)
        else:
            updateMetaData = "action=moduleEdited moduleId=%s parentModuleId=%s insertBeforeModuleId=%s" % (moduleId, parentModuleId, insertBeforeModuleId)

        errorMessage = sv.commitChanges(app,view,viewXML, updateMetaData)
        if (errorMessage) :
            return self.getErrorResponse(errorMessage)
        return '{"success":true}'


    def viewIsEditable(self,app,view) :
        if (app=="sideview_utils"):
            return (view.find("example_")==0)
        else :
            return (app not in sv.uneditableViews or view not in sv.uneditableViews[app])

    def getErrorResponse(self,message) :
        resp = {"success":False}
        resp["message"] = str(message)
        return json.dumps(resp)

    def getUneditableAppResponse(self,app,view) :
        sideviewMessage = """We cannot let you use the Sideview Editor to edit 
        pieces of the Sideview app itself because that would be too silly.  
        You are however free to edit any view whose name begins with the word 'example'."""
        generalMessage = """This view has been mysteriously marked as uneditable. 
        Or maybe it wasn't mysterious.  Honestly we can't tell. But you can't edit it."""
        
        if (app=="sideview_utils") :
            return self.getErrorResponse(sideviewMessage)
        else :
            return self.getErrorResponse(generalMessage)

    def getAttributeErrorResponse(self,attName, legalValues, submittedValue, isRequired) :
        resp = {"success":False}
        messageTemplate = "ERROR - %s is not allowed as a value for %s. Set one of the allowed values - (%s)"
        if (isRequired) : 
            messageTemplate += "."
        else :
            messageTemplate += " or leave it blank."

        resp["message"] = messageTemplate % (submittedValue, attName, ", ".join(legalValues))
        return json.dumps(resp)
